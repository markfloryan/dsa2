
def insertionSort(list, start, end):
	#TODO: IMPLEMENT INSERTION SORT

def partition(list, i, j):
	#TODO: NEED PARTITION FOR QUICKSORT

def quickSort(list, i, j, minSize):
	#TODO: IMPLEMENT QUICKSORT
