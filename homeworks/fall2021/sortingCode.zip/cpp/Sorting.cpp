
#include <iostream>
#include <vector>

using namespace std;

void insertionSort(vector<int> &list, int start, int end) {
	//TODO: IMPLEMENT INSERTION SORT
}

int partition(vector<int> &list, int i, int j) {
	//TODO: IMPLEMENT PARTITION FOR QUICKSORT
}

void quickSort(vector<int> &list, int i, int j, int minSize) {
	//TODO: IMPLEMENT QUICKSORT
}



