
public class Sorting {

	public static<T extends Comparable<T>> void insertionSort(T[] list, int start, int end) {
		//TODO: IMPLEMENT INSERTION SORT. MAKE SURE TO USE .compareTo FOR COMPARISONS
	}
	
	public static<T extends Comparable<T>> void quickSort(T[] list, int i, int j, int minSize) {
		//TODO: IMPLEMENT INSERTION SORT
	}
	
	private static<T extends Comparable<T>> int partition(T[] list, int i, int j) {
		//TODO: WILL NEED PARTITION FOR QUICKSORT!
	}

}
